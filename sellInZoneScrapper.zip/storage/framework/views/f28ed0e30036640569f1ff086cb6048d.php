<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Multi Scraper'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <nav style="background-color: #1f2937; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center;">
        <div style="font-size: 1.25rem; font-weight: 600;">Multi Scraper Panel</div>
        <div style="display: flex; gap: 2rem;">
            <a href="#" style="color: white; text-decoration: none;">Scrapers</a>
            <a href="#" style="color: white; text-decoration: none;">Products</a>
            <a href="#" style="color: white; text-decoration: none;">Settings</a>
        </div>
    </nav>
    <main style="max-width: 1200px; margin: 2rem auto; padding: 0 1rem;">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>

<?php /**PATH C:\MAMP\htdocs\sellInZoneScrapper\resources\views/layouts/app.blade.php ENDPATH**/ ?>