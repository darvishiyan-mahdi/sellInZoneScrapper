<?php

namespace App\Console\Commands;

use App\Models\Product;
use App\Services\Wordpress\WordpressSyncService;
use Illuminate\Console\Command;

class SyncWordpressProductsCommand extends Command
{
    protected $signature = 'wordpress:sync {product_id?}';

    protected $description = 'Sync products to WordPress';

    public function handle(WordpressSyncService $syncService): int
    {
        $productId = $this->argument('product_id');

        if ($productId) {
            $product = Product::where('id', $productId)
                ->where('status', 'active')
                ->first();

            if (!$product) {
                $this->error("Product not found or not active: {$productId}");
                return Command::FAILURE;
            }

            $this->syncSingleProduct($product, $syncService);
        } else {
            $this->syncAllProducts($syncService);
        }

        return Command::SUCCESS;
    }

    protected function syncSingleProduct(Product $product, WordpressSyncService $syncService): void
    {
        $this->info("Syncing product: {$product->title} (ID: {$product->id})");

        try {
            $syncService->syncProduct($product);
            $this->info("Successfully synced product: {$product->title}");
        } catch (\Exception $e) {
            $this->error("Failed to sync product: {$e->getMessage()}");
        }
    }

    protected function syncAllProducts(WordpressSyncService $syncService): void
    {
        $query = Product::where('status', 'active')
            ->where(function ($q) {
                $q->whereDoesntHave('wordpressMapping')
                    ->orWhereHas('wordpressMapping', function ($subQ) {
                        $subQ->whereColumn('products.updated_at', '>', 'product_wordpress_mappings.last_synced_at')
                            ->orWhereNull('product_wordpress_mappings.last_synced_at');
                    });
            });

        $total = $query->count();

        if ($total === 0) {
            $this->info('No products to sync.');
            return;
        }

        $this->info("Found {$total} products to sync.");

        $bar = $this->output->createProgressBar($total);
        $bar->start();

        $query->chunk(50, function ($products) use ($syncService, $bar) {
            foreach ($products as $product) {
                try {
                    $syncService->syncProduct($product);
                } catch (\Exception $e) {
                    $this->newLine();
                    $this->warn("Failed to sync product {$product->id}: {$e->getMessage()}");
                }
                $bar->advance();
            }
        });

        $bar->finish();
        $this->newLine();
        $this->info("Sync completed.");
    }
}

