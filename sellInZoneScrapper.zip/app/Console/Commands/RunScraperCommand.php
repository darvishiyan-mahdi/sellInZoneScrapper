<?php

namespace App\Console\Commands;

use App\Models\ScrapeJob;
use App\Models\Website;
use App\Services\Scrapers\ScraperRegistry;
use Illuminate\Console\Command;

class RunScraperCommand extends Command
{
    protected $signature = 'scrape:run {website?}';

    protected $description = 'Run scraper for a specific website or all active websites';

    public function handle(ScraperRegistry $registry): int
    {
        $websiteArgument = $this->argument('website');

        if ($websiteArgument) {
            $website = Website::where('slug', $websiteArgument)
                ->orWhere('id', $websiteArgument)
                ->where('is_active', true)
                ->first();

            if (!$website) {
                $this->error("Website not found or inactive: {$websiteArgument}");
                return Command::FAILURE;
            }

            $this->scrapeWebsite($website, $registry);
        } else {
            $websites = Website::where('is_active', true)->get();

            if ($websites->isEmpty()) {
                $this->info('No active websites found.');
                return Command::SUCCESS;
            }

            foreach ($websites as $website) {
                $this->scrapeWebsite($website, $registry);
            }
        }

        return Command::SUCCESS;
    }

    protected function scrapeWebsite(Website $website, ScraperRegistry $registry): void
    {
        $this->info("Starting scrape for: {$website->name}");

        $job = ScrapeJob::create([
            'website_id' => $website->id,
            'status' => 'pending',
        ]);

        try {
            $scraper = $registry->forWebsite($website);
            $scraper->run($job);

            $this->info("Scrape completed for: {$website->name}");
            $this->info("  Found: {$job->total_found}, Created: {$job->total_created}, Updated: {$job->total_updated}");
        } catch (\Exception $e) {
            $this->error("Scrape failed for: {$website->name}");
            $this->error("  Error: {$e->getMessage()}");
        }
    }
}

