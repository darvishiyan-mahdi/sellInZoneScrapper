<?php

namespace App\Console\Commands;

use App\Models\ScrapeJob;
use App\Services\Scrapers\Lululemon\LululemonCategoryScraper;
use App\Services\Scrapers\Lululemon\LululemonPdpClient;
use App\Services\Scrapers\Lululemon\LululemonPdpParser;
use Illuminate\Console\Command;

class ScrapeLululemonWomenBrasUnderwear extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'scrape:lululemon:women-bras-underwear';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Parse Lululemon women bras & underwear category JSON and persist products into DB.';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Starting Lululemon women bras & underwear scraper...');

        try {
            // Ensure the Lululemon website exists
            $website = LululemonCategoryScraper::ensureWebsite();
            $this->info("Using website: {$website->name} (ID: {$website->id})");

            // Create a scrape job
            $job = ScrapeJob::create([
                'website_id' => $website->id,
                'status' => 'pending',
            ]);

            $this->info("Created scrape job ID: {$job->id}");

            // Run the scraper
            $pdpClient = new LululemonPdpClient($website);
            $pdpParser = new LululemonPdpParser();
            $scraper = new LululemonCategoryScraper($website, $pdpClient, $pdpParser);
            $scraper->scrapeWomenBrasAndUnderwear($job);

            // Refresh job to get updated values
            $job->refresh();

            // Display summary
            $this->info('');
            $this->info('Scrape completed successfully!');
            $this->info("Status: {$job->status}");
            $this->info("Total found: {$job->total_found}");
            $this->info("Total created: {$job->total_created}");
            $this->info("Total updated: {$job->total_updated}");

            if ($job->started_at && $job->finished_at) {
                $duration = $job->started_at->diffInSeconds($job->finished_at);
                $this->info("Duration: {$duration} seconds");
            }

            return Command::SUCCESS;

        } catch (\Exception $e) {
            $this->error('Scrape failed: ' . $e->getMessage());
            $this->error($e->getTraceAsString());
            return Command::FAILURE;
        }
    }
}

