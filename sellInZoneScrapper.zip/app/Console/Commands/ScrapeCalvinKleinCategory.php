<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\Scrapers\CalvinKlein\CalvinKleinCategoryScraper;
use Illuminate\Console\Command;

class ScrapeCalvinKleinCategory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'scrapers:calvinklein:collect-links {categoryUrl}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Collect all product detail page URLs from a Calvin Klein category page.';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $categoryUrl = $this->argument('categoryUrl');

        if (empty($categoryUrl)) {
            $this->error('Category URL is required.');
            return Command::FAILURE;
        }

        $this->info("Starting Calvin Klein category link collection...");
        $this->info("Category URL: {$categoryUrl}");

        try {
            $scraper = new CalvinKleinCategoryScraper();
            $productLinks = $scraper->collectProductLinks($categoryUrl);

            $this->info('');
            $this->info('Link collection completed successfully!');
            $this->info("Total unique product links found: " . count($productLinks));

            // Display first 10 links as preview
            if (count($productLinks) > 0) {
                $this->info('');
                $this->info('First 10 product links (preview):');
                $preview = array_slice($productLinks, 0, 10);
                foreach ($preview as $index => $link) {
                    $this->line("  " . ($index + 1) . ". {$link}");
                }
                
                if (count($productLinks) > 10) {
                    $this->info("  ... and " . (count($productLinks) - 10) . " more");
                }
            }

            return Command::SUCCESS;

        } catch (\Exception $e) {
            $this->error('Link collection failed: ' . $e->getMessage());
            $this->error($e->getTraceAsString());
            return Command::FAILURE;
        }
    }
}

