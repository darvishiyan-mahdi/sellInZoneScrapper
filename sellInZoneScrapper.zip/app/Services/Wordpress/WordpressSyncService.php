<?php

namespace App\Services\Wordpress;

use App\Models\Product;
use App\Models\ProductWordpressMapping;
use Illuminate\Support\Facades\Log;

class WordpressSyncService
{
    protected WordpressApiClient $apiClient;

    public function __construct(WordpressApiClient $apiClient)
    {
        $this->apiClient = $apiClient;
    }

    public function syncProduct(Product $product): void
    {
        try {
            $response = $this->apiClient->upsertProduct($product);

            $mapping = $product->wordpressMapping()->firstOrNew();
            $mapping->product_id = $product->id;
            $mapping->wordpress_product_id = $response['id'] ?? null;
            $mapping->wordpress_site_url = config('wordpress.base_url');
            $mapping->last_synced_at = now();
            $mapping->last_sync_status = 'success';
            $mapping->last_sync_payload = $response;
            $mapping->save();

            Log::info("Product synced to WordPress", [
                'product_id' => $product->id,
                'wordpress_product_id' => $mapping->wordpress_product_id,
            ]);
        } catch (\Exception $e) {
            $mapping = $product->wordpressMapping()->firstOrNew();
            $mapping->product_id = $product->id;
            $mapping->wordpress_site_url = config('wordpress.base_url');
            $mapping->last_synced_at = now();
            $mapping->last_sync_status = 'failed';
            $mapping->last_sync_payload = [
                'error' => $e->getMessage(),
            ];
            $mapping->save();

            Log::error("Failed to sync product to WordPress", [
                'product_id' => $product->id,
                'error' => $e->getMessage(),
            ]);

            throw $e;
        }
    }
}

