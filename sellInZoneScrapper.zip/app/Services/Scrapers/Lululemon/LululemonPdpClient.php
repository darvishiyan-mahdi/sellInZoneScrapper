<?php

declare(strict_types=1);

namespace App\Services\Scrapers\Lululemon;

use App\Models\Website;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class LululemonPdpClient
{
    protected string $baseUrl;
    protected ?string $cookie = null;
    protected bool $cookieGenerated = false;

    public function __construct(?Website $website = null)
    {
        if ($website === null) {
            $website = Website::where('slug', 'lululemon')->first();
            if (!$website) {
                throw new \RuntimeException('Lululemon website not found in database');
            }
        }
        $this->baseUrl = rtrim($website->base_url, '/');
    }

    /**
     * Generate cookies by making an initial request to the homepage
     * Tries multiple methods: HTTP client with header extraction, then cURL with cookie jar
     * 
     * @return string|null The cookie string or null if failed
     */
    protected function generateCookie(): ?string
    {
        if ($this->cookieGenerated && $this->cookie !== null) {
            return $this->cookie;
        }

        // Try method 1: Laravel HTTP client with Set-Cookie header extraction
        $cookie = $this->generateCookieFromHeaders();
        if ($cookie) {
            $this->cookie = $cookie;
            $this->cookieGenerated = true;
            return $cookie;
        }

        // Try method 2: cURL with cookie jar file (fallback)
        $cookie = $this->generateCookieFromCurlJar();
        if ($cookie) {
            $this->cookie = $cookie;
            $this->cookieGenerated = true;
            return $cookie;
        }

        $this->cookieGenerated = true;
        return null;
    }

    /**
     * Method 1: Generate cookies using Laravel HTTP client and extracting from Set-Cookie headers
     * 
     * @return string|null The cookie string or null if failed
     */
    protected function generateCookieFromHeaders(): ?string
    {
        try {
            Log::info('Generating cookies from Lululemon homepage (method: HTTP headers)...');
            
            $response = Http::timeout(30)
                ->connectTimeout(15)
                ->withHeaders([
                    'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'Accept-Language' => 'en-US,en;q=0.9',
                    'Accept-Encoding' => 'identity',
                    'Cache-Control' => 'max-age=0',
                    'Connection' => 'keep-alive',
                    'Upgrade-Insecure-Requests' => '1',
                    'Sec-Fetch-Dest' => 'document',
                    'Sec-Fetch-Mode' => 'navigate',
                    'Sec-Fetch-Site' => 'none',
                    'Sec-Fetch-User' => '?1',
                    'Sec-CH-UA' => '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
                    'Sec-CH-UA-Mobile' => '?0',
                    'Sec-CH-UA-Platform' => '"Windows"',
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
                ])
                ->withOptions([
                    'verify' => true,
                    'allow_redirects' => [
                        'max' => 5,
                        'strict' => true,
                        'referer' => true,
                        'protocols' => ['http', 'https'],
                    ],
                    'curl' => [
                        CURLOPT_ENCODING => 'identity',
                        CURLOPT_SSL_VERIFYPEER => true,
                        CURLOPT_SSL_VERIFYHOST => 2,
                    ],
                ])
                ->get($this->baseUrl . '/');

            if ($response->successful()) {
                $cookies = [];
                
                // Extract cookies from Set-Cookie headers
                $headers = $response->headers();
                
                // Handle both single and multiple Set-Cookie headers
                $setCookieHeaders = [];
                if (isset($headers['Set-Cookie'])) {
                    if (is_array($headers['Set-Cookie'])) {
                        $setCookieHeaders = $headers['Set-Cookie'];
                    } else {
                        $setCookieHeaders = [$headers['Set-Cookie']];
                    }
                }
                
                // Also check for lowercase header name (some servers use lowercase)
                if (isset($headers['set-cookie'])) {
                    if (is_array($headers['set-cookie'])) {
                        $setCookieHeaders = array_merge($setCookieHeaders, $headers['set-cookie']);
                    } else {
                        $setCookieHeaders[] = $headers['set-cookie'];
                    }
                }

                foreach ($setCookieHeaders as $cookieHeader) {
                    // Extract cookie name=value from Set-Cookie header
                    // Format: name=value; Path=/; Domain=.example.com; HttpOnly; Secure
                    if (preg_match('/^([^=]+)=([^;]+)/', trim($cookieHeader), $matches)) {
                        $cookieName = trim($matches[1]);
                        $cookieValue = trim($matches[2]);
                        
                        // Skip empty values unless it's a session cookie
                        if (!empty($cookieName)) {
                            $cookies[$cookieName] = $cookieValue;
                        }
                    }
                }

                // Also try to get cookies using Guzzle's SetCookie parser if available
                // This provides better parsing of cookie attributes (domain, path, etc.)
                if (class_exists('\GuzzleHttp\Cookie\SetCookie')) {
                    try {
                        $guzzleResponse = $response->toPsrResponse();
                        
                        // Parse cookies from response headers
                        foreach ($guzzleResponse->getHeader('Set-Cookie') as $cookieString) {
                            try {
                                $cookie = \GuzzleHttp\Cookie\SetCookie::fromString($cookieString);
                                $domain = $cookie->getDomain();
                                $host = parse_url($this->baseUrl, PHP_URL_HOST);
                                
                                // Check if cookie domain matches our base URL
                                if (empty($domain) || 
                                    $domain === $host ||
                                    strpos($host, ltrim($domain, '.')) !== false ||
                                    strpos($domain, $host) !== false) {
                                    $cookies[$cookie->getName()] = $cookie->getValue();
                                }
                            } catch (\Exception $e) {
                                // Skip invalid cookie strings
                                continue;
                            }
                        }
                    } catch (\Exception $e) {
                        // Ignore Guzzle parsing errors, use header parsing instead
                        Log::debug('Guzzle cookie parsing failed, using header parsing', [
                            'error' => $e->getMessage(),
                        ]);
                    }
                }

                if (!empty($cookies)) {
                    // Build cookie string
                    $cookiePairs = [];
                    foreach ($cookies as $name => $value) {
                        $cookiePairs[] = $name . '=' . $value;
                    }
                    
                    $cookieString = implode('; ', $cookiePairs);
                    
                    Log::info('Successfully generated cookies from headers', [
                        'cookie_count' => count($cookies),
                        'cookie_length' => strlen($cookieString),
                        'cookie_names' => array_keys($cookies),
                    ]);
                    
                    return $cookieString;
                } else {
                    Log::warning('No cookies found in Set-Cookie headers', [
                        'status' => $response->status(),
                        'headers_count' => count($setCookieHeaders),
                    ]);
                }
            } else {
                Log::warning('Failed to generate cookies from headers', [
                    'status' => $response->status(),
                ]);
            }
            
        } catch (\Exception $e) {
            Log::warning('Exception while generating cookies from headers', [
                'error' => $e->getMessage(),
            ]);
        }

        return null;
    }

    /**
     * Method 2: Generate cookies using cURL with cookie jar file (fallback method)
     * 
     * @return string|null The cookie string or null if failed
     */
    protected function generateCookieFromCurlJar(): ?string
    {
        try {
            Log::info('Generating cookies from Lululemon homepage (method: cURL cookie jar)...');
            
            $cookieFile = sys_get_temp_dir() . '/lululemon_cookies_' . md5($this->baseUrl) . '.txt';
            
            // Use cURL directly for better cookie handling
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $this->baseUrl . '/',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 5,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_CONNECTTIMEOUT => 15,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_COOKIEJAR => $cookieFile,
                CURLOPT_COOKIEFILE => $cookieFile,
                CURLOPT_ENCODING => 'identity',
                CURLOPT_HTTPHEADER => [
                    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'Accept-Language: en-US,en;q=0.9',
                    'Accept-Encoding: identity',
                    'Cache-Control: max-age=0',
                    'Connection: keep-alive',
                    'Upgrade-Insecure-Requests: 1',
                    'Sec-Fetch-Dest: document',
                    'Sec-Fetch-Mode: navigate',
                    'Sec-Fetch-Site: none',
                    'Sec-Fetch-User: ?1',
                    'Sec-CH-UA: "Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
                    'Sec-CH-UA-Mobile: ?0',
                    'Sec-CH-UA-Platform: "Windows"',
                    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
                ],
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);

            if ($httpCode >= 200 && $httpCode < 400 && $response !== false) {
                // Parse cookies from the cookie jar file
                $cookies = [];
                if (file_exists($cookieFile)) {
                    $cookieContent = file_get_contents($cookieFile);
                    $lines = explode("\n", $cookieContent);
                    
                    foreach ($lines as $line) {
                        $line = trim($line);
                        if (empty($line) || $line[0] === '#') {
                            continue;
                        }
                        
                        // Parse Netscape cookie format: domain, flag, path, secure, expiration, name, value
                        $parts = explode("\t", $line);
                        if (count($parts) >= 7) {
                            $cookieName = trim($parts[5]);
                            $cookieValue = trim($parts[6]);
                            
                            // Skip expired cookies (expiration < current time)
                            $expiration = isset($parts[4]) ? (int) $parts[4] : 0;
                            if ($expiration > 0 && $expiration < time()) {
                                continue;
                            }
                            
                            if (!empty($cookieName) && !empty($cookieValue)) {
                                $cookies[$cookieName] = $cookieValue;
                            }
                        }
                    }
                }

                if (!empty($cookies)) {
                    // Build cookie string
                    $cookiePairs = [];
                    foreach ($cookies as $name => $value) {
                        $cookiePairs[] = $name . '=' . $value;
                    }
                    
                    $cookieString = implode('; ', $cookiePairs);
                    
                    Log::info('Successfully generated cookies from cURL jar', [
                        'cookie_count' => count($cookies),
                        'cookie_length' => strlen($cookieString),
                        'cookie_names' => array_keys($cookies),
                    ]);
                    
                    return $cookieString;
                } else {
                    Log::warning('No cookies found in cookie jar file', [
                        'cookie_file' => $cookieFile,
                        'http_code' => $httpCode,
                    ]);
                }
            } else {
                Log::warning('Failed to generate cookies from cURL jar', [
                    'http_code' => $httpCode,
                    'error' => $error,
                ]);
            }
            
        } catch (\Exception $e) {
            Log::error('Exception while generating cookies from cURL jar', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
        }

        return null;
    }

    /**
     * Get cookie to use for requests
     * Tries env variable first, then generates if needed
     * 
     * @return string|null
     */
    public function getCookie(): ?string
    {
        // First try environment variable
        $envCookie = env('LULULEMON_COOKIE');
        if ($envCookie) {
            return $envCookie;
        }

        // If no env cookie and we haven't generated one yet, try to generate
        if (!$this->cookieGenerated) {
            return $this->generateCookie();
        }

        // Return cached generated cookie
        return $this->cookie;
    }

    /**
     * Initialize cookies - generate if not in environment
     * Call this at the start of scraping to ensure cookies are ready
     * 
     * @return bool True if cookie is available, false otherwise
     */
    public function initializeCookie(): bool
    {
        $cookie = $this->getCookie();
        if ($cookie) {
            $source = env('LULULEMON_COOKIE') ? 'environment' : 'generated';
            Log::info('Cookie initialized', [
                'source' => $source,
                'cookie_length' => strlen($cookie),
            ]);
            return true;
        }
        
        Log::warning('Failed to initialize cookie');
        return false;
    }

    /**
     * Force regeneration of cookies
     * Resets the cookie state and generates a new cookie
     * 
     * @return bool True if cookie was successfully regenerated, false otherwise
     */
    public function regenerateCookie(): bool
    {
        Log::info('Forcing cookie regeneration...');
        
        // Reset cookie state
        $this->cookie = null;
        $this->cookieGenerated = false;
        
        // Generate new cookie
        $cookie = $this->generateCookie();
        
        if ($cookie) {
            $this->cookie = $cookie;
            $this->cookieGenerated = true;
            Log::info('Cookie successfully regenerated', [
                'cookie_length' => strlen($cookie),
            ]);
            return true;
        }
        
        Log::warning('Failed to regenerate cookie');
        return false;
    }

    public function fetchHtml(string $relativePdpUrl, int $maxRetries = 3): ?string
    {
        $url = $this->baseUrl . $relativePdpUrl;

        $cookie = $this->getCookie();
        if ($cookie) {
            $cookieSource = env('LULULEMON_COOKIE') ? 'environment' : 'generated';
            Log::debug('Using cookie', [
                'source' => $cookieSource,
                'cookie_length' => strlen($cookie),
            ]);
        } else {
            Log::warning('No cookie available - requests may fail with 403');
        }

        $attempt = 0;
        $lastException = null;

        while ($attempt < $maxRetries) {
            $attempt++;
            
            try {
                $response = Http::timeout(45)
                    ->connectTimeout(20)
                    ->withHeaders([
                        'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'Accept-Language' => 'en-US,en;q=0.9,fa;q=0.8',
                        'Accept-Encoding' => 'identity',
                        'Cache-Control' => 'max-age=0',
                        'Connection' => 'keep-alive',
                        'Upgrade-Insecure-Requests' => '1',
                        'Sec-Fetch-Dest' => 'document',
                        'Sec-Fetch-Mode' => 'navigate',
                        'Sec-Fetch-Site' => 'same-origin',
                        'Sec-Fetch-User' => '?1',
                        'Sec-CH-UA' => '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
                        'Sec-CH-UA-Mobile' => '?0',
                        'Sec-CH-UA-Platform' => '"Windows"',
                        'Priority' => 'u=0, i',
                        'Referer' => $this->baseUrl . '/',
                        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
                    ])
                    ->withOptions([
                        'verify' => true,
                        'allow_redirects' => [
                            'max' => 5,
                            'strict' => true,
                            'referer' => true,
                            'protocols' => ['http', 'https'],
                        ],
                        'curl' => [
                            CURLOPT_ENCODING => 'identity',
                            CURLOPT_SSL_VERIFYPEER => true,
                            CURLOPT_SSL_VERIFYHOST => 2,
                        ],
                    ]);

                if ($cookie) {
                    $response = $response->withHeaders(['Cookie' => $cookie]);
                }

                $response = $response->get($url);

                if (!$response->successful()) {
                    $statusCode = $response->status();
                    
                    // 403 errors - try to regenerate cookie if it was generated (not from env)
                    if ($statusCode === 403) {
                        Log::warning('Non-200 HTTP response fetching PDP', [
                            'url' => $url,
                            'http_code' => $statusCode,
                            'has_cookie' => !empty($cookie),
                            'attempt' => $attempt,
                        ]);

                        // If cookie was generated (not from env), try to regenerate it once
                        if (empty(env('LULULEMON_COOKIE')) && $attempt === 1) {
                            Log::info('403 Forbidden with generated cookie, attempting to regenerate...');
                            $this->cookie = null;
                            $this->cookieGenerated = false;
                            $cookie = $this->generateCookie();
                            
                            if ($cookie) {
                                Log::info('Cookie regenerated, retrying request');
                                sleep(2); // Small delay before retry
                                continue;
                            }
                        }

                        if (empty($cookie)) {
                            Log::error('403 Forbidden - Could not generate valid cookie. Please set LULULEMON_COOKIE in your .env file or check network connectivity.');
                        } else {
                            Log::error('403 Forbidden - Cookie may be expired or invalid, or rate limiting is active. Please update LULULEMON_COOKIE in your .env file.');
                        }

                        return null;
                    }

                    // For other non-200 responses, retry if we have attempts left
                    if ($attempt < $maxRetries) {
                        $waitTime = pow(2, $attempt); // Exponential backoff: 2s, 4s, 8s
                        Log::warning('Non-200 HTTP response, retrying', [
                            'url' => $url,
                            'http_code' => $statusCode,
                            'attempt' => $attempt,
                            'max_retries' => $maxRetries,
                            'wait_seconds' => $waitTime,
                        ]);
                        sleep($waitTime);
                        continue;
                    }

                    Log::warning('Non-200 HTTP response fetching PDP after all retries', [
                        'url' => $url,
                        'http_code' => $statusCode,
                        'has_cookie' => !empty($cookie),
                        'attempts' => $attempt,
                    ]);

                    return null;
                }

                $html = $response->body();

                if (empty($html)) {
                    if ($attempt < $maxRetries) {
                        $waitTime = pow(2, $attempt);
                        Log::warning('Empty response body, retrying', [
                            'url' => $url,
                            'attempt' => $attempt,
                            'wait_seconds' => $waitTime,
                        ]);
                        sleep($waitTime);
                        continue;
                    }

                    Log::warning('Empty response body from PDP after all retries', ['url' => $url]);
                    return null;
                }

                if ($attempt > 1) {
                    Log::info('Successfully fetched PDP HTML after retry', [
                        'url' => $url,
                        'html_length' => strlen($html),
                        'attempts' => $attempt,
                    ]);
                } else {
                    Log::debug('Successfully fetched PDP HTML', [
                        'url' => $url,
                        'html_length' => strlen($html),
                    ]);
                }

                return $html;

            } catch (\Exception $e) {
                $lastException = $e;
                $errorMessage = $e->getMessage();
                
                // Check if it's a retryable error
                $isRetryable = false;
                if (strpos($errorMessage, 'Operation timed out') !== false || 
                    strpos($errorMessage, 'cURL error 28') !== false) {
                    $isRetryable = true;
                } elseif (strpos($errorMessage, 'SSL') !== false || 
                          strpos($errorMessage, 'cURL error 56') !== false) {
                    $isRetryable = true;
                } elseif (strpos($errorMessage, 'Connection') !== false) {
                    $isRetryable = true;
                }

                if ($isRetryable && $attempt < $maxRetries) {
                    $waitTime = pow(2, $attempt); // Exponential backoff: 2s, 4s, 8s
                    Log::warning('Retryable error fetching PDP, retrying', [
                        'url' => $url,
                        'error' => $errorMessage,
                        'attempt' => $attempt,
                        'max_retries' => $maxRetries,
                        'wait_seconds' => $waitTime,
                    ]);
                    sleep($waitTime);
                    continue;
                }

                // Non-retryable error or max retries reached
                Log::warning('Error fetching PDP', [
                    'url' => $url,
                    'error' => $errorMessage,
                    'attempt' => $attempt,
                    'max_retries' => $maxRetries,
                    'is_retryable' => $isRetryable,
                ]);
                
                if ($attempt >= $maxRetries) {
                    return null;
                }
            }
        }

        return null;
    }
}

