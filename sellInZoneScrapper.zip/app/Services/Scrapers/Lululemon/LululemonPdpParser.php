<?php

declare(strict_types=1);

namespace App\Services\Scrapers\Lululemon;

use Symfony\Component\DomCrawler\Crawler;

class LululemonPdpParser
{
    public function extractAttributes(string $html): array
    {
        $attributes = [];
        $crawler = new Crawler($html);

        $this->extractAccordionAttributes($crawler, $attributes);
        $this->extractWhyWeMadeThisAttributes($crawler, $attributes);

        return $attributes;
    }

    protected function extractAccordionAttributes(Crawler $crawler, array &$attributes): void
    {
        $accordionItems = $crawler->filter('[class*="accordion-item_accordionItemHeadingTitle"]');

        foreach ($accordionItems as $headingElement) {
            $headingCrawler = new Crawler($headingElement);
            $headingText = trim($headingCrawler->text());

            if (empty($headingText)) {
                continue;
            }

            $detailsElement = $headingElement;
            while ($detailsElement !== null) {
                if ($detailsElement->nodeType === XML_ELEMENT_NODE && 
                    ($detailsElement->nodeName === 'details' || 
                     ($detailsElement->getAttribute('class') && strpos($detailsElement->getAttribute('class'), 'accordion') !== false))) {
                    break;
                }
                $detailsElement = $detailsElement->parentNode;
            }

            if ($detailsElement === null) {
                $detailsElement = $headingElement->parentNode;
                while ($detailsElement !== null && $detailsElement->nodeType !== XML_ELEMENT_NODE) {
                    $detailsElement = $detailsElement->parentNode;
                }
            }

            if ($detailsElement === null) {
                continue;
            }

            $detailsCrawler = new Crawler($detailsElement);
            $panelContent = $detailsCrawler->filter('[class*="accordion-item_accordionItemPanelContent"]');

            if ($panelContent->count() === 0) {
                continue;
            }

            $panelText = $this->extractPanelText($panelContent->first());

            if (empty($panelText)) {
                continue;
            }

            $headingTextClean = trim($headingText);
            $headingTextClean = preg_replace('/\s*\(Click to Expand\)\s*/i', '', $headingTextClean);
            $headingTextClean = preg_replace('/\s+/', ' ', $headingTextClean);
            
            $attributeName = 'pdp_accordion_' . $this->slugify($headingTextClean);
            $attributes[$attributeName] = $headingTextClean . '=>' . $panelText;

            if (stripos($headingText, 'Material') !== false && stripos($headingText, 'care') !== false) {
                $this->extractMaterialAndCareDetails($panelContent->first(), $attributes);
            }
        }
    }

    protected function extractPanelText(Crawler $panelCrawler): string
    {
        $textParts = [];

        $panelCrawler->filter('li span, li, p')->each(function (Crawler $node) use (&$textParts) {
            $text = trim($node->text());
            if (!empty($text)) {
                $textParts[] = $text;
            }
        });

        if (empty($textParts)) {
            $text = trim($panelCrawler->text());
            if (!empty($text)) {
                $textParts[] = $text;
            }
        }

        return implode("\n", $textParts);
    }

    protected function extractMaterialAndCareDetails(Crawler $panelCrawler, array &$attributes): void
    {
        $materialsText = '';
        $careText = '';

        $panelCrawler->filter('dl, ul')->each(function (Crawler $node) use (&$materialsText, &$careText) {
            $nodeText = trim($node->text());
            $parentText = '';

            $parent = $node->getNode(0)?->parentNode;
            if ($parent !== null) {
                $parentCrawler = new Crawler($parent);
                $parentText = trim($parentCrawler->text());
            }

            if (stripos($parentText, 'Material') !== false || stripos($nodeText, 'Material') !== false) {
                $materialsText = $nodeText;
            } elseif (stripos($parentText, 'Care') !== false || stripos($nodeText, 'Care') !== false) {
                $careText = $nodeText;
            }
        });

        if (!empty($materialsText)) {
            $attributes['pdp_materials_raw'] = $materialsText;
        }

        if (!empty($careText)) {
            $attributes['pdp_care_instructions_raw'] = $careText;
        }
    }

    protected function extractWhyWeMadeThisAttributes(Crawler $crawler, array &$attributes): void
    {
        // Look for elements with class containing "why-we-made-this_text__wQAFQ" or "why-we-made-this_text"
        // This should match elements like: <p class="why-we-made-this_text__wQAFQ">...</p>
        $textElements = $crawler->filter('[class*="why-we-made-this_text"]');

        if ($textElements->count() > 0) {
            // Get the first matching element
            $textElement = $textElements->first();
            
            // Extract the HTML content (not just text)
            $htmlContent = $textElement->html();
            
            if (!empty($htmlContent)) {
                // Save as attribute name "why-we-made-this" with HTML content as value
                $attributes['why-we-made-this'] = trim($htmlContent);
            }
        }
        
        // Also keep the old method as fallback for backward compatibility
        $container = $crawler->filter('[class*="why-we-made-this_textContainer"]');

        if ($container->count() > 0) {
            $heading = $container->filter('h2[class*="why-we-made-this_heading"]');
            $text = $container->filter('p[class*="why-we-made-this_text"]');

            $headingText = '';
            $bodyText = '';

            if ($heading->count() > 0) {
                $headingText = trim($heading->first()->text());
                $headingText = preg_replace('/\s+/', ' ', $headingText);
            }

            if ($text->count() > 0) {
                $bodyText = trim($text->first()->text());
            }

            // Only add pdp_why if why-we-made-this wasn't already set
            if (!empty($headingText) && !empty($bodyText) && !isset($attributes['why-we-made-this'])) {
                $attributes['pdp_why'] = $headingText . '=>' . $bodyText;
            }
        }
    }

    protected function slugify(string $text): string
    {
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9]+/', '_', $text);
        $text = trim($text, '_');
        return $text;
    }
}

