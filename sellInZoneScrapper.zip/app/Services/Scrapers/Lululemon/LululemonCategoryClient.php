<?php

declare(strict_types=1);

namespace App\Services\Scrapers\Lululemon;

use App\Models\Website;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class LululemonCategoryClient
{
    protected string $baseUrl;
    protected string $graphqlEndpoint;
    protected ?string $cookie = null;
    protected bool $cookieGenerated = false;
    protected LululemonPdpClient $pdpClient;

    public function __construct(?Website $website = null, ?LululemonPdpClient $pdpClient = null)
    {
        if ($website === null) {
            $website = Website::where('slug', 'lululemon')->first();
            if (!$website) {
                throw new \RuntimeException('Lululemon website not found in database');
            }
        }
        $this->baseUrl = rtrim($website->base_url, '/');
        $this->graphqlEndpoint = config('websites.lululemon.graphql_endpoint', $this->baseUrl . '/api/graphql');
        
        // Ensure we have a valid endpoint
        if (empty($this->graphqlEndpoint)) {
            $this->graphqlEndpoint = $this->baseUrl . '/api/graphql';
        }
        
        // Log the endpoint being used for debugging
        Log::debug('LululemonCategoryClient initialized', [
            'base_url' => $this->baseUrl,
            'graphql_endpoint' => $this->graphqlEndpoint,
        ]);
        
        // Reuse PDP client for cookie generation
        $this->pdpClient = $pdpClient ?? new LululemonPdpClient($website);
    }

    /**
     * Get cookie to use for requests
     * Reuses the PDP client's cookie generation logic
     * 
     * @return string|null
     */
    protected function getCookie(): ?string
    {
        // First try environment variable
        $envCookie = env('LULULEMON_COOKIE');
        if ($envCookie) {
            return $envCookie;
        }

        // Use PDP client's cookie generation
        if (!$this->pdpClient->initializeCookie()) {
            return null;
        }

        // Get cookie from PDP client
        return $this->pdpClient->getCookie();
    }

    /**
     * Get value from array using dot-notation path
     * 
     * @param array $data The data array
     * @param string $path Dot-notation path (e.g., 'data.categoryPageData.products')
     * @return mixed|null The value at the path or null if not found
     */
    protected function getValueByPath(array $data, string $path)
    {
        $segments = explode('.', $path);
        foreach ($segments as $segment) {
            if (!is_array($data) || !array_key_exists($segment, $data)) {
                return null;
            }
            $data = $data[$segment];
        }
        return $data;
    }

    /**
     * Fetch a category page from the GraphQL API
     * 
     * @param string $categoryPath Category path (e.g., "women-bras-and-underwear/n1sv6a")
     * @param int $page Page number (1-based)
     * @param int $pageSize Number of products per page
     * @param int $maxRetries Maximum number of retry attempts
     * @return array|null Decoded JSON response or null on failure
     */
    public function fetchCategoryPage(
        string $categoryPath,
        int $page = 1,
        int $pageSize = 40,
        int $maxRetries = 3
    ): ?array {
        $cookie = $this->getCookie();
        
        if ($cookie) {
            $cookieSource = env('LULULEMON_COOKIE') ? 'environment' : 'generated';
            Log::debug('Using cookie for GraphQL request', [
                'source' => $cookieSource,
                'cookie_length' => strlen($cookie),
                'page' => $page,
            ]);
        } else {
            Log::warning('No cookie available for GraphQL request - requests may fail', [
                'page' => $page,
            ]);
        }

        // Load GraphQL query from config
        $query = config('websites.lululemon.graphql_queries.category_page');
        if (empty($query)) {
            throw new \RuntimeException(
                'Lululemon category GraphQL query not configured. ' .
                'Set LULULEMON_GRAPHQL_CATEGORY_QUERY in .env or config/websites/lululemon.php. ' .
                'Capture the query from browser DevTools Network tab when loading a category page.'
            );
        }

        // Extract operationName from query if not explicitly set
        // Look for pattern: query OperationName(...) or mutation OperationName(...)
        $operationName = config('websites.lululemon.graphql_operation_name', null);
        if (empty($operationName)) {
            // Try to extract from query string
            if (preg_match('/^\s*(?:query|mutation|subscription)\s+(\w+)/i', trim($query), $matches)) {
                $operationName = $matches[1];
            }
        }

        // Parse categoryPath to extract category slug and nValue (cdpHash)
        // Format: "women-bras-and-underwear/n1sv6a"
        $categoryParts = explode('/', trim($categoryPath, '/'));
        $categorySlug = $categoryParts[0] ?? '';
        $nValue = $categoryParts[1] ?? null;

        // Build GraphQL query variables matching the actual API
        // These can be overridden via config if needed
        $variables = [
            'category' => $categorySlug,
            'cdpHash' => $nValue,
            'nValue' => $nValue,
            'page' => $page,
            'pageSize' => $pageSize,
            'locale' => 'en_US',
            'sl' => 'US',
            'useHighlights' => true,
            'onlyStore' => false,
            'abFlags' => ['cdpSeodsEnabled'],
            'styleboost' => [],
            'forceMemberCheck' => false,
        ];

        // Merge any additional variables from config
        $configVariables = config('websites.lululemon.graphql_variables', []);
        if (is_array($configVariables)) {
            $variables = array_merge($variables, $configVariables);
        }

        // Build GraphQL request body matching browser format
        $payload = [
            'query' => $query,
            'variables' => $variables,
        ];
        
        // Add operationName if we found one (required by some GraphQL servers)
        if (!empty($operationName)) {
            $payload['operationName'] = $operationName;
        }
        $url = $this->graphqlEndpoint;
        $useGraphQL = true;

        $attempt = 0;
        $lastException = null;

        while ($attempt < $maxRetries) {
            $attempt++;

            try {
                $headers = [
                    'Accept' => 'application/json',
                    'Accept-Language' => 'en-US,en;q=0.9',
                    'Accept-Encoding' => 'gzip, deflate, br',
                    'Content-Type' => 'application/json',
                    'Origin' => $this->baseUrl,
                    'Referer' => $this->baseUrl . '/c/' . $categoryPath,
                    'Sec-Fetch-Dest' => $useGraphQL ? 'empty' : 'document',
                    'Sec-Fetch-Mode' => $useGraphQL ? 'cors' : 'navigate',
                    'Sec-Fetch-Site' => 'same-origin',
                    'Sec-CH-UA' => '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
                    'Sec-CH-UA-Mobile' => '?0',
                    'Sec-CH-UA-Platform' => '"Windows"',
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
                ];

                // Add operationName header if available (some GraphQL servers use this)
                if (!empty($operationName)) {
                    $headers['x-apollo-operation-name'] = $operationName;
                }

                $response = Http::timeout(45)
                    ->connectTimeout(20)
                    ->withHeaders($headers)
                    ->withOptions([
                        'verify' => true,
                        'curl' => [
                            CURLOPT_ENCODING => 'gzip, deflate, br',
                            CURLOPT_SSL_VERIFYPEER => true,
                            CURLOPT_SSL_VERIFYHOST => 2,
                        ],
                    ]);

                if ($cookie) {
                    $response = $response->withHeaders(['Cookie' => $cookie]);
                }

                // Log full request details for debugging (only on first attempt)
                if ($attempt === 1) {
                    Log::debug('GraphQL request details', [
                        'endpoint' => $url,
                        'method' => 'POST',
                        'operation_name' => $operationName ?? 'N/A',
                        'headers' => array_merge($headers, ['Cookie' => $cookie ? '[REDACTED]' : 'N/A']),
                        'payload_keys' => array_keys($payload),
                        'variables_keys' => array_keys($variables),
                    ]);
                }

                // Use GET for REST, POST for GraphQL
                if ($useGraphQL) {
                    $response = $response->post($url, $payload);
                } else {
                    $response = $response->get($url);
                }

                if (!$response->successful()) {
                    $statusCode = $response->status();

                    // 403 errors - try to regenerate cookie if it was generated (not from env)
                    if ($statusCode === 403) {
                        Log::warning('403 Forbidden on GraphQL request', [
                            'endpoint' => $this->graphqlEndpoint,
                            'page' => $page,
                            'has_cookie' => !empty($cookie),
                            'attempt' => $attempt,
                        ]);

                        // If cookie was generated (not from env), try to regenerate it once
                        if (empty(env('LULULEMON_COOKIE')) && $attempt === 1) {
                            Log::info('403 Forbidden with generated cookie, attempting to regenerate...');
                            $this->pdpClient->regenerateCookie();
                            $cookie = $this->getCookie();
                            
                            if ($cookie) {
                                Log::info('Cookie regenerated, retrying GraphQL request');
                                sleep(2); // Small delay before retry
                                continue;
                            }
                        }

                        if (empty($cookie)) {
                            Log::error('403 Forbidden - Could not generate valid cookie. Please set LULULEMON_COOKIE in your .env file or check network connectivity.');
                        } else {
                            Log::error('403 Forbidden - Cookie may be expired or invalid, or rate limiting is active.');
                        }

                        return null;
                    }

                    // For 400 errors, log the response body to understand what's wrong
                    if ($statusCode === 400) {
                        $errorBody = $response->body();
                        $errorData = json_decode($errorBody, true);
                        
                        // Extract GraphQL error details
                        $errorMessage = null;
                        $errorCode = null;
                        if (isset($errorData['errors']) && is_array($errorData['errors']) && !empty($errorData['errors'])) {
                            $firstError = $errorData['errors'][0];
                            $errorMessage = $firstError['message'] ?? null;
                            $errorCode = $firstError['extensions']['code'] ?? null;
                        }
                        
                        // Log GraphQL errors for debugging
                        if ($errorMessage) {
                            Log::warning('GraphQL error', [
                                'error' => $errorMessage,
                                'error_code' => $errorCode,
                                'page' => $page,
                                'attempt' => $attempt,
                            ]);
                        }
                        
                        // Truncate query for logging (first 500 chars)
                        $queryPreview = is_string($query) ? substr($query, 0, 500) : 'N/A';
                        $variablesPreview = json_encode($variables, JSON_UNESCAPED_SLASHES);
                        if (strlen($variablesPreview) > 500) {
                            $variablesPreview = substr($variablesPreview, 0, 500) . '...';
                        }
                        
                        Log::error('400 Bad Request on API request', [
                            'endpoint' => $useGraphQL ? $this->graphqlEndpoint : $url,
                            'method' => $useGraphQL ? 'POST' : 'GET',
                            'page' => $page,
                            'attempt' => $attempt,
                            'operation_name' => $operationName ?? 'N/A',
                            'graphql_error' => $errorMessage,
                            'graphql_error_code' => $errorCode,
                            'response_body' => $errorBody,
                            'response_data' => $errorData,
                            'query_preview' => $queryPreview,
                            'variables_preview' => $variablesPreview,
                        ]);
                        
                        // Don't retry 400 errors - they're client errors (invalid query/schema)
                        // If it's a GraphQL validation error, the query needs to be fixed
                        if ($errorCode === 'GRAPHQL_VALIDATION_FAILED') {
                            Log::error(
                                'GraphQL validation failed. The query field may not exist in the schema. ' .
                                'Please capture the current query from browser DevTools and update LULULEMON_GRAPHQL_CATEGORY_QUERY. ' .
                                'Endpoint: ' . $this->graphqlEndpoint . ', OperationName: ' . ($operationName ?? 'N/A')
                            );
                            
                            // Try to introspect the schema to see available fields (one-time debug)
                            if ($attempt === 1) {
                                $this->trySchemaIntrospection($url, $cookie, $headers);
                                
                                // Try common alternative endpoints
                                $this->tryAlternativeEndpoints($this->baseUrl, $payload, $cookie, $headers, $operationName);
                            }
                        }
                        
                        return null;
                    }

                    // For other non-200 responses, retry if we have attempts left
                    if ($attempt < $maxRetries) {
                        $waitTime = pow(2, $attempt); // Exponential backoff: 2s, 4s, 8s
                        $errorBody = $response->body();
                        Log::warning('Non-200 HTTP response on API request, retrying', [
                            'endpoint' => $useGraphQL ? $this->graphqlEndpoint : $url,
                            'method' => $useGraphQL ? 'POST' : 'GET',
                            'page' => $page,
                            'http_code' => $statusCode,
                            'attempt' => $attempt,
                            'max_retries' => $maxRetries,
                            'wait_seconds' => $waitTime,
                            'response_preview' => substr($errorBody, 0, 500),
                        ]);
                        sleep($waitTime);
                        continue;
                    }

                    $errorBody = $response->body();
                    Log::warning('Non-200 HTTP response on API request after all retries', [
                        'endpoint' => $useGraphQL ? $this->graphqlEndpoint : $url,
                        'method' => $useGraphQL ? 'POST' : 'GET',
                        'page' => $page,
                        'http_code' => $statusCode,
                        'has_cookie' => !empty($cookie),
                        'attempts' => $attempt,
                        'response_body' => $errorBody,
                    ]);

                    return null;
                }

                $body = $response->body();
                $data = json_decode($body, true);

                if (json_last_error() !== JSON_ERROR_NONE) {
                    if ($attempt < $maxRetries) {
                        $waitTime = pow(2, $attempt);
                        Log::warning('Failed to parse JSON response, retrying', [
                            'page' => $page,
                            'error' => json_last_error_msg(),
                            'attempt' => $attempt,
                            'wait_seconds' => $waitTime,
                        ]);
                        sleep($waitTime);
                        continue;
                    }

                    Log::error('Failed to parse JSON response after all retries', [
                        'page' => $page,
                        'error' => json_last_error_msg(),
                        'response_preview' => substr($body, 0, 500),
                    ]);
                    return null;
                }

                // Check for GraphQL errors (if using GraphQL)
                if ($useGraphQL && isset($data['errors'])) {
                    $errorMessages = [];
                    $errorCodes = [];
                    foreach ($data['errors'] as $error) {
                        $errorMessages[] = $error['message'] ?? 'Unknown error';
                        if (isset($error['extensions']['code'])) {
                            $errorCodes[] = $error['extensions']['code'];
                        }
                    }
                    
                    Log::error('GraphQL errors in response', [
                        'page' => $page,
                        'errors' => $data['errors'],
                        'error_messages' => $errorMessages,
                        'error_codes' => array_unique($errorCodes),
                    ]);
                    return null;
                }

                // Validate response structure using configurable paths
                $rootField = config('websites.lululemon.graphql_root_field', 'categoryPageData');
                $productPath = config('websites.lululemon.graphql_product_path', 'data.categoryPageData.products');
                
                // GraphQL wraps response in data.{rootField}
                if ($useGraphQL) {
                    if (!isset($data['data'])) {
                        Log::error('Invalid GraphQL response structure - missing data wrapper', [
                            'page' => $page,
                            'response_keys' => array_keys($data),
                            'response_preview' => json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES),
                        ]);
                        return null;
                    }
                    
                    // Check if root field exists
                    if (!isset($data['data'][$rootField])) {
                        $availableFields = array_keys($data['data']);
                        Log::error('Invalid GraphQL response structure - root field not found', [
                            'page' => $page,
                            'expected_root_field' => $rootField,
                            'available_fields' => $availableFields,
                            'response_preview' => json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES),
                        ]);
                        return null;
                    }
                }

                // Get products using configurable path
                $products = $this->getValueByPath($data, $productPath);
                if ($products === null) {
                    Log::warning('Products not found at configured path', [
                        'page' => $page,
                        'product_path' => $productPath,
                        'response_keys' => array_keys($data),
                        'data_keys' => isset($data['data']) ? array_keys($data['data']) : null,
                    ]);
                    // Don't fail completely - return the data and let caller handle it
                }

                if ($attempt > 1) {
                    Log::info('Successfully fetched category page after retry', [
                        'page' => $page,
                        'attempts' => $attempt,
                        'products_count' => is_array($products) ? count($products) : 0,
                    ]);
                } else {
                    Log::debug('Successfully fetched category page', [
                        'page' => $page,
                        'products_count' => is_array($products) ? count($products) : 0,
                    ]);
                }

                // Return full response data - caller will extract products using getValueByPath
                return $data;

            } catch (\Exception $e) {
                $lastException = $e;
                $errorMessage = $e->getMessage();

                // Check if it's a retryable error
                $isRetryable = false;
                if (strpos($errorMessage, 'Operation timed out') !== false ||
                    strpos($errorMessage, 'cURL error 28') !== false) {
                    $isRetryable = true;
                } elseif (strpos($errorMessage, 'SSL') !== false ||
                          strpos($errorMessage, 'cURL error 56') !== false) {
                    $isRetryable = true;
                } elseif (strpos($errorMessage, 'Connection') !== false) {
                    $isRetryable = true;
                }

                if ($isRetryable && $attempt < $maxRetries) {
                    $waitTime = pow(2, $attempt); // Exponential backoff: 2s, 4s, 8s
                    Log::warning('Retryable error on API request, retrying', [
                        'endpoint' => $useGraphQL ? $this->graphqlEndpoint : $url,
                        'method' => $useGraphQL ? 'POST' : 'GET',
                        'page' => $page,
                        'error' => $errorMessage,
                        'attempt' => $attempt,
                        'max_retries' => $maxRetries,
                        'wait_seconds' => $waitTime,
                    ]);
                    sleep($waitTime);
                    continue;
                }

                // Non-retryable error or max retries reached
                Log::error('Error on API request', [
                    'endpoint' => $useGraphQL ? $this->graphqlEndpoint : $url,
                    'method' => $useGraphQL ? 'POST' : 'GET',
                    'page' => $page,
                    'error' => $errorMessage,
                    'attempt' => $attempt,
                    'max_retries' => $maxRetries,
                    'is_retryable' => $isRetryable,
                ]);

                if ($attempt >= $maxRetries) {
                    return null;
                }
            }
        }

        return null;
    }

    /**
     * Initialize cookies - ensure cookies are ready for requests
     * 
     * @return bool True if cookie is available, false otherwise
     */
    public function initializeCookie(): bool
    {
        return $this->pdpClient->initializeCookie();
    }

    /**
     * Force regeneration of cookies
     * 
     * @return bool True if cookie was successfully regenerated, false otherwise
     */
    public function regenerateCookie(): bool
    {
        return $this->pdpClient->regenerateCookie();
    }

    /**
     * Try to introspect the GraphQL schema to see available fields
     * This helps debug when the endpoint doesn't recognize a field
     * 
     * @param string $endpoint The GraphQL endpoint URL
     * @param string|null $cookie The cookie string
     * @param array $headers The headers to use
     * @return void
     */
    protected function trySchemaIntrospection(string $endpoint, ?string $cookie, array $headers): void
    {
        try {
            $introspectionQuery = '{
                __schema {
                    queryType {
                        fields {
                            name
                            description
                        }
                    }
                }
            }';
            
            $introspectionPayload = [
                'query' => $introspectionQuery,
            ];
            
            $response = Http::timeout(10)
                ->connectTimeout(5)
                ->withHeaders($headers);
            
            if ($cookie) {
                $response = $response->withHeaders(['Cookie' => $cookie]);
            }
            
            $response = $response->post($endpoint, $introspectionPayload);
            
            if ($response->successful()) {
                $data = $response->json();
                $fields = $data['data']['__schema']['queryType']['fields'] ?? [];
                $fieldNames = array_column($fields, 'name');
                
                Log::info('GraphQL schema introspection successful', [
                    'endpoint' => $endpoint,
                    'available_fields' => $fieldNames,
                    'field_count' => count($fieldNames),
                ]);
            } else {
                Log::warning('GraphQL schema introspection failed', [
                    'endpoint' => $endpoint,
                    'status' => $response->status(),
                    'response' => $response->body(),
                ]);
            }
        } catch (\Exception $e) {
            Log::debug('GraphQL schema introspection error', [
                'endpoint' => $endpoint,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Try common alternative GraphQL endpoints to find the correct one
     * 
     * @param string $baseUrl The base URL
     * @param array $payload The GraphQL payload
     * @param string|null $cookie The cookie string
     * @param array $headers The headers to use
     * @param string|null $operationName The operation name
     * @return void
     */
    protected function tryAlternativeEndpoints(string $baseUrl, array $payload, ?string $cookie, array $headers, ?string $operationName): void
    {
        // Common alternative endpoints to try
        $alternativeEndpoints = [
            '/snb/graphql',
            '/alpine/graphql',
            '/api/snb/graphql',
            '/api/alpine/graphql',
            '/graphql',
            '/api/v1/graphql',
        ];
        
        Log::info('Trying alternative GraphQL endpoints to find the correct one...');
        
        foreach ($alternativeEndpoints as $path) {
            $testEndpoint = rtrim($baseUrl, '/') . $path;
            
            try {
                $response = Http::timeout(10)
                    ->connectTimeout(5)
                    ->withHeaders($headers);
                
                if ($cookie) {
                    $response = $response->withHeaders(['Cookie' => $cookie]);
                }
                
                $response = $response->post($testEndpoint, $payload);
                
                if ($response->successful()) {
                    $data = $response->json();
                    
                    // Check if we got a successful response (no errors)
                    if (!isset($data['errors']) || empty($data['errors'])) {
                        // Check if categoryPageData exists in response
                        if (isset($data['data']['categoryPageData'])) {
                            Log::info('✅ FOUND CORRECT ENDPOINT!', [
                                'endpoint' => $testEndpoint,
                                'status' => $response->status(),
                                'has_categoryPageData' => true,
                            ]);
                            Log::info('Update your .env file:', [
                                'LULULEMON_GRAPHQL_ENDPOINT' => $testEndpoint,
                            ]);
                            return;
                        } else {
                            Log::debug('Endpoint responded successfully but no categoryPageData', [
                                'endpoint' => $testEndpoint,
                                'status' => $response->status(),
                                'data_keys' => isset($data['data']) ? array_keys($data['data']) : null,
                            ]);
                        }
                    } else {
                        $errorCode = $data['errors'][0]['extensions']['code'] ?? null;
                        if ($errorCode !== 'GRAPHQL_VALIDATION_FAILED') {
                            Log::debug('Endpoint exists but returned different error', [
                                'endpoint' => $testEndpoint,
                                'status' => $response->status(),
                                'error_code' => $errorCode,
                            ]);
                        }
                    }
                } else {
                    Log::debug('Endpoint test failed', [
                        'endpoint' => $testEndpoint,
                        'status' => $response->status(),
                    ]);
                }
            } catch (\Exception $e) {
                Log::debug('Error testing alternative endpoint', [
                    'endpoint' => $testEndpoint,
                    'error' => $e->getMessage(),
                ]);
            }
        }
        
        Log::warning('No working alternative endpoint found. Please check browser DevTools for the correct endpoint URL.');
    }
}

