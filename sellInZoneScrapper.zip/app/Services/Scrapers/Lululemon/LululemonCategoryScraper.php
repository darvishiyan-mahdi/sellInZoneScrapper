<?php

declare(strict_types=1);

namespace App\Services\Scrapers\Lululemon;

use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\ProductMedia;
use App\Models\ScrapeJob;
use App\Models\Website;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class LululemonCategoryScraper
{
    protected Website $website;
    protected LululemonPdpClient $pdpClient;
    protected LululemonPdpParser $pdpParser;
    protected LululemonCategoryClient $categoryClient;
    protected static bool $firstHtmlSaved = false;

    /**
     * Get value from array using dot-notation path
     * 
     * @param array $data The data array
     * @param string $path Dot-notation path (e.g., 'data.categoryPageData.products')
     * @return mixed|null The value at the path or null if not found
     */
    protected function getValueByPath(array $data, string $path)
    {
        $segments = explode('.', $path);
        foreach ($segments as $segment) {
            if (!is_array($data) || !array_key_exists($segment, $data)) {
                return null;
            }
            $data = $data[$segment];
        }
        return $data;
    }

    public function __construct(Website $website, LululemonPdpClient $pdpClient, LululemonPdpParser $pdpParser)
    {
        $this->website = $website;
        $this->pdpClient = $pdpClient;
        $this->pdpParser = $pdpParser;
        $this->categoryClient = new LululemonCategoryClient($website, $pdpClient);
    }

    /**
     * Scrape the women bras and underwear category from Lululemon.
     * 
     * @param ScrapeJob|null $job Optional scrape job to track progress
     * @return void
     */
    public function scrapeWomenBrasAndUnderwear(?ScrapeJob $job = null): void
    {
        try {
            if ($job) {
                $job->update([
                    'status' => 'running',
                    'started_at' => now(),
                ]);
            }

            // Get category configuration
            $categoryPath = config('websites.lululemon.categories.women_bras_underwear', 'women-bras-and-underwear/n1sv6a');
            $pageSize = (int) config('websites.lululemon.pagination.page_size', 40);
            $maxRetries = (int) config('websites.lululemon.pagination.max_retries', 3);

            Log::info('Starting Lululemon category scrape', [
                'category' => $categoryPath,
                'page_size' => $pageSize,
            ]);

            // Initialize cookies before making requests
            if (!$this->categoryClient->initializeCookie()) {
                Log::warning('Cookie initialization failed, but continuing with scraping. Requests may fail.');
            }

            $totalFound = 0;
            $totalCreated = 0;
            $totalUpdated = 0;
            $currentPage = 1;
            $totalPages = null;
            $productIndex = 0;

            // Pagination loop - fetch all pages
            do {
                Log::info("Fetching category page {$currentPage}" . ($totalPages ? " of {$totalPages}" : ''));

                $data = $this->categoryClient->fetchCategoryPage($categoryPath, $currentPage, $pageSize, $maxRetries);

                if ($data === null) {
                    throw new \RuntimeException("Failed to fetch category page {$currentPage} after {$maxRetries} retries");
                }

                // Use configurable paths to extract data
                $rootField = config('websites.lululemon.graphql_root_field', 'categoryPageData');
                $productPath = config('websites.lululemon.graphql_product_path', 'data.categoryPageData.products');
                $totalPagesPath = config('websites.lululemon.graphql_total_pages_path', 'data.categoryPageData.totalProductPages');
                $currentPagePath = config('websites.lululemon.graphql_current_page_path', 'data.categoryPageData.currentPage');

                // Validate root field exists
                $rootData = $data['data'][$rootField] ?? null;
                if ($rootData === null) {
                    $availableFields = isset($data['data']) ? array_keys($data['data']) : [];
                    Log::error('Invalid response structure - root field not found', [
                        'page' => $currentPage,
                        'expected_root_field' => $rootField,
                        'available_fields' => $availableFields,
                        'response_keys' => array_keys($data),
                    ]);
                    throw new \RuntimeException(
                        "Invalid response structure on page {$currentPage}: " .
                        "expected root field '{$rootField}' not found. " .
                        "Available fields: " . implode(', ', $availableFields)
                    );
                }

                // Extract products using configurable path
                $products = $this->getValueByPath($data, $productPath) ?? [];
                
                if (!is_array($products)) {
                    Log::error('Products path did not return an array', [
                        'page' => $currentPage,
                        'product_path' => $productPath,
                        'products_type' => gettype($products),
                    ]);
                    $products = [];
                }
                
                if (empty($products)) {
                    if ($currentPage === 1) {
                        // First page with no products is a critical error
                        throw new \RuntimeException(
                            "No products returned for first page of category. " .
                            "Check that LULULEMON_GRAPHQL_PRODUCT_PATH is correct. " .
                            "Current path: {$productPath}"
                        );
                    }
                    Log::warning('No products found in response', [
                        'page' => $currentPage,
                        'product_path' => $productPath,
                        'root_field_keys' => array_keys($rootData),
                    ]);
                    break; // No more products, exit loop
                }

                // Update total pages from first response using configurable path
                if ($totalPages === null) {
                    $totalPagesValue = $this->getValueByPath($data, $totalPagesPath);
                    if ($totalPagesValue !== null) {
                        $totalPages = (int) $totalPagesValue;
                        Log::info("Total pages determined: {$totalPages}", [
                            'total_pages_path' => $totalPagesPath,
                        ]);
                    }
                }

                $pageProductCount = count($products);
                $totalFound += $pageProductCount;

                Log::info("Processing {$pageProductCount} products from page {$currentPage}", [
                    'total_products_so_far' => $totalFound,
                ]);

                // Process products from this page
                foreach ($products as $productNode) {
                    try {
                        // Regenerate cookie every 10 products (except for environment cookies)
                        if ($productIndex > 0 && $productIndex % 10 === 0 && empty(env('LULULEMON_COOKIE'))) {
                            Log::info("Regenerating cookie after processing {$productIndex} products");
                            if (!$this->categoryClient->regenerateCookie()) {
                                Log::warning('Cookie regeneration failed, but continuing with scraping');
                            }
                            // Small delay after cookie regeneration
                            sleep(1);
                        }

                        $result = $this->mapProductToDatabase($productNode);
                        
                        if ($result['created']) {
                            $totalCreated++;
                        } else {
                            $totalUpdated++;
                        }

                        $productIndex++;

                        // Small delay between products to avoid rate limiting
                        if ($productIndex < $totalFound) {
                            usleep(500000); // 0.5 seconds
                        }
                    } catch (\Exception $e) {
                        // Log error but continue with next product
                        Log::error('Error processing product', [
                            'product_index' => $productIndex,
                            'page' => $currentPage,
                            'error' => $e->getMessage(),
                            'product_data' => [
                                'repositoryId' => $productNode['repositoryId'] ?? null,
                                'displayName' => $productNode['displayName'] ?? null,
                            ],
                        ]);
                        // Continue to next product instead of crashing
                        continue;
                    }
                }

                // Check if there are more pages
                $hasNextPage = false;
                if ($totalPages !== null) {
                    $hasNextPage = $currentPage < $totalPages;
                } else {
                    // Fallback: if we got products, assume there might be more
                    // This is less ideal but handles cases where totalProductPages might not be set
                    $hasNextPage = $pageProductCount >= $pageSize;
                    
                    // Also check currentPage from response if available
                    $responseCurrentPage = $this->getValueByPath($data, $currentPagePath);
                    if ($responseCurrentPage !== null && is_numeric($responseCurrentPage)) {
                        // If we can't determine total pages, at least verify we're on the right page
                        if ((int) $responseCurrentPage !== $currentPage) {
                            Log::warning('Page number mismatch', [
                                'expected_page' => $currentPage,
                                'response_page' => $responseCurrentPage,
                            ]);
                        }
                    }
                }

                if ($hasNextPage) {
                    $currentPage++;
                    // Small delay between page requests
                    sleep(1);
                } else {
                    break; // No more pages
                }

            } while (true);

            if ($job) {
                $job->update([
                    'status' => 'completed',
                    'finished_at' => now(),
                    'total_found' => $totalFound,
                    'total_created' => $totalCreated,
                    'total_updated' => $totalUpdated,
                ]);
            }

            Log::info("Scrape completed successfully", [
                'total_found' => $totalFound,
                'total_created' => $totalCreated,
                'total_updated' => $totalUpdated,
                'pages_processed' => $currentPage,
            ]);

        } catch (\Exception $e) {
            $errorMessage = $e->getMessage();
            if (strlen($errorMessage) > 1000) {
                $errorMessage = substr($errorMessage, 0, 1000) . '...';
            }

            if ($job) {
                $job->update([
                    'status' => 'failed',
                    'finished_at' => now(),
                    'error_message' => $errorMessage,
                ]);
            }

            Log::error("Scrape failed: " . $e->getMessage(), [
                'exception' => $e,
            ]);

            throw $e;
        }
    }

    /**
     * Map a single product node from the JSON response to database tables.
     * 
     * @param array $productNode The product node from the JSON
     * @return array ['created' => bool, 'product' => Product]
     */
    protected function mapProductToDatabase(array $productNode): array
    {
        return DB::transaction(function () use ($productNode) {
            // Extract basic product data
            $externalId = $productNode['repositoryId'] ?? $productNode['productId'] ?? null;
            
            if (!$externalId) {
                throw new \RuntimeException('Product missing repositoryId/productId');
            }

            $displayName = $productNode['displayName'] ?? '';
            $unifiedId = $productNode['unifiedId'] ?? null;
            $pdpUrl = $productNode['pdpUrl'] ?? '';
            
            // Derive slug from unifiedId or pdpUrl
            $slug = $unifiedId;
            if (!$slug && $pdpUrl) {
                // Extract slug from pdpUrl: /p/category/slug/_/prodId
                $parts = explode('/', trim($pdpUrl, '/'));
                if (count($parts) >= 2) {
                    $slug = $parts[1];
                }
            }
            if (!$slug) {
                $slug = \Illuminate\Support\Str::slug($displayName);
            }

            // Extract price
            $listPrice = $productNode['listPrice'] ?? [];
            $price = !empty($listPrice) ? (float) $listPrice[0] : null;

            // Extract currency
            $currency = $productNode['currencyCode'] ?? null;

            // Upsert product
            $product = Product::updateOrCreate(
                [
                    'website_id' => $this->website->id,
                    'external_id' => $externalId,
                ],
                [
                    'title' => $displayName,
                    'slug' => $slug,
                    'description' => null, // Will be enriched from PDP in a later step
                    'price' => $price,
                    'currency' => $currency,
                    'stock_quantity' => null, // Not available in this JSON
                    'status' => 'draft',
                    'raw_data' => $productNode,
                ]
            );

            $wasRecentlyCreated = $product->wasRecentlyCreated;

            // Delete existing attributes and media before recreating
            $product->attributes()->delete();
            $product->media()->delete();

            // Map product attributes (GraphQL + PDP)
            $this->mapProductAttributes($product, $productNode);

            // Map product media
            $this->mapProductMedia($product, $productNode);

            return [
                'created' => $wasRecentlyCreated,
                'product' => $product,
            ];
        });
    }

    /**
     * Map product attributes from the product node.
     * 
     * @param Product $product
     * @param array $productNode
     * @return void
     */
    protected function mapProductAttributes(Product $product, array $productNode): void
    {
        $attributes = [];

        // category_unified_id
        if (isset($productNode['parentCategoryUnifiedId'])) {
            $attributes[] = [
                'product_id' => $product->id,
                'name' => 'category_unified_id',
                'value' => $productNode['parentCategoryUnifiedId'],
            ];
        }

        // pdp_url (full URL)
        $pdpUrl = $productNode['pdpUrl'] ?? '';
        if ($pdpUrl) {
            $fullPdpUrl = rtrim($this->website->base_url, '/') . $pdpUrl;
            $attributes[] = [
                'product_id' => $product->id,
                'name' => 'pdp_url',
                'value' => $fullPdpUrl,
            ];
        }

        // all_available_sizes (JSON-encoded)
        if (isset($productNode['allAvailableSizes'])) {
            $attributes[] = [
                'product_id' => $product->id,
                'name' => 'all_available_sizes',
                'value' => json_encode($productNode['allAvailableSizes']),
            ];
        }

        // intended_cup_size (JSON-encoded)
        if (isset($productNode['intendedCupSize'])) {
            $attributes[] = [
                'product_id' => $product->id,
                'name' => 'intended_cup_size',
                'value' => json_encode($productNode['intendedCupSize']),
            ];
        }

        // on_sale
        $isOnSale = $productNode['productOnSale'] ?? false;
        $attributes[] = [
            'product_id' => $product->id,
            'name' => 'on_sale',
            'value' => $isOnSale ? '1' : '0',
        ];

        // sale_price (first element of listPrice as text)
        if (isset($productNode['listPrice']) && is_array($productNode['listPrice']) && !empty($productNode['listPrice'])) {
            $listPriceFirstElement = $productNode['listPrice'][0];
            $attributes[] = [
                'product_id' => $product->id,
                'name' => 'sale_price',
                'value' => (string) $listPriceFirstElement,
            ];
        }

        // unified_id
        if (isset($productNode['unifiedId'])) {
            $attributes[] = [
                'product_id' => $product->id,
                'name' => 'unified_id',
                'value' => $productNode['unifiedId'],
            ];
        }

        // variants (JSON-encoded skuStyleOrder)
        if (isset($productNode['skuStyleOrder'])) {
            $attributes[] = [
                'product_id' => $product->id,
                'name' => 'variants',
                'value' => json_encode($productNode['skuStyleOrder']),
            ];
        }

        // Fetch and parse PDP HTML for additional attributes
        // if (!empty($pdpUrl)) {
        //     $html = $this->pdpClient->fetchHtml($pdpUrl);
            
        //     // Add a small delay between requests to avoid rate limiting
        //     // Delay is configurable via env, default 1 second
        //     $delaySeconds = (float) env('LULULEMON_PDP_REQUEST_DELAY', 1.0);
        //     if ($delaySeconds > 0) {
        //         usleep((int) ($delaySeconds * 1000000)); // Convert seconds to microseconds
        //     }
            
        //     if ($html !== null) {
        //         // Save the first successfully fetched HTML page
        //         if (!self::$firstHtmlSaved) {
        //             $this->saveFirstProductHtml($html, $product->id, $pdpUrl);
        //             self::$firstHtmlSaved = true;
        //         }
                
        //         $pdpAttributes = $this->pdpParser->extractAttributes($html);
                
        //         Log::debug('PDP attributes extracted', [
        //             'product_id' => $product->id,
        //             'attributes_count' => count($pdpAttributes),
        //             'attribute_names' => array_keys($pdpAttributes),
        //         ]);
                
        //         foreach ($pdpAttributes as $name => $value) {
        //             $attributes[] = [
        //                 'product_id' => $product->id,
        //                 'name' => $name,
        //                 'value' => $value,
        //             ];
        //         }
        //     } else {
        //         Log::warning('Failed to fetch PDP HTML', [
        //             'product_id' => $product->id,
        //             'pdp_url' => $pdpUrl,
        //         ]);
        //     }
        // }

        // Bulk insert attributes
        if (!empty($attributes)) {
            ProductAttribute::insert($attributes);
        }
    }

    /**
     * Save the first successfully fetched product HTML page for debugging
     * 
     * @param string $html The HTML content
     * @param int $productId The product ID
     * @param string $pdpUrl The PDP URL
     * @return void
     */
    protected function saveFirstProductHtml(string $html, int $productId, string $pdpUrl): void
    {
        try {
            // Create debug directory if it doesn't exist
            $debugDir = storage_path('logs/lululemon');
            if (!file_exists($debugDir)) {
                mkdir($debugDir, 0755, true);
            }

            // Generate filename with timestamp and product ID
            $timestamp = now()->format('Y-m-d_H-i-s');
            $filename = "first-product-html-{$timestamp}-product-{$productId}.html";
            $filePath = $debugDir . '/' . $filename;

            // Save HTML to file
            file_put_contents($filePath, $html);

            Log::info('First product HTML page saved', [
                'product_id' => $productId,
                'pdp_url' => $pdpUrl,
                'file_path' => $filePath,
                'file_size' => filesize($filePath),
            ]);
        } catch (\Exception $e) {
            Log::warning('Failed to save first product HTML page', [
                'product_id' => $productId,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Map product media from the product node.
     * 
     * @param Product $product
     * @param array $productNode
     * @return void
     */
    protected function mapProductMedia(Product $product, array $productNode): void
    {
        $media = [];
        $displayName = $productNode['displayName'] ?? '';
        $isFirstVariant = true;
        $isFirstImage = true;

        // Map images from skuStyleOrder variants
        $skuStyleOrder = $productNode['skuStyleOrder'] ?? [];
        
        foreach ($skuStyleOrder as $variant) {
            $colorName = $variant['colorName'] ?? '';
            $size = $variant['size'] ?? '';
            $images = $variant['images'] ?? [];

            foreach ($images as $imageUrl) {
                if (empty($imageUrl)) {
                    continue;
                }

                $altText = trim("{$displayName} - {$colorName} - size {$size}");
                
                $media[] = [
                    'product_id' => $product->id,
                    'type' => 'image',
                    'source_url' => $imageUrl,
                    'local_path' => $imageUrl, // Initially set equal to source_url
                    'alt_text' => $altText,
                    'is_primary' => $isFirstVariant && $isFirstImage,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];

                $isFirstImage = false;
            }

            $isFirstVariant = false;
        }

        // Optionally map swatches as additional media
        $swatches = $productNode['swatches'] ?? [];
        foreach ($swatches as $swatch) {
            // Primary image from swatch
            if (!empty($swatch['primaryImage'])) {
                $colorId = $swatch['colorId'] ?? '';
                $media[] = [
                    'product_id' => $product->id,
                    'type' => 'swatch_image',
                    'source_url' => $swatch['primaryImage'],
                    'local_path' => $swatch['primaryImage'],
                    'alt_text' => "{$displayName} - swatch - color {$colorId}",
                    'is_primary' => false,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }

            // Hover image from swatch (if different)
            if (!empty($swatch['hoverImage']) && $swatch['hoverImage'] !== $swatch['primaryImage']) {
                $colorId = $swatch['colorId'] ?? '';
                $media[] = [
                    'product_id' => $product->id,
                    'type' => 'swatch_image',
                    'source_url' => $swatch['hoverImage'],
                    'local_path' => $swatch['hoverImage'],
                    'alt_text' => "{$displayName} - swatch hover - color {$colorId}",
                    'is_primary' => false,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }
        }

        // Bulk insert media
        if (!empty($media)) {
            ProductMedia::insert($media);
        }
    }

    /**
     * Ensure the Lululemon website exists in the database.
     * Updates existing record if found to ensure it has correct configuration.
     * 
     * @return Website
     */
    public static function ensureWebsite(): Website
    {
        $website = Website::firstOrCreate(
            [
                'slug' => 'lululemon',
            ],
            [
                'name' => 'Lululemon',
                'base_url' => 'https://shop.lululemon.com',
                'is_active' => true,
                'scraper_class' => self::class,
                'extra_config' => [
                    'women_bras_underwear_category' => 'women-bras-and-underwear/n1sv6a',
                ],
            ]
        );

        // Update existing record to ensure it has correct configuration
        if (!$website->wasRecentlyCreated) {
            $website->update([
                'name' => 'Lululemon',
                'base_url' => 'https://shop.lululemon.com',
                'is_active' => true,
                'scraper_class' => self::class,
                'extra_config' => [
                    'women_bras_underwear_category' => 'women-bras-and-underwear/n1sv6a',
                ],
            ]);
        }

        return $website;
    }
}

