<?php

return [
    'base_url' => env('WORDPRESS_BASE_URL'),
    'consumer_key' => env('WORDPRESS_CONSUMER_KEY'),
    'consumer_secret' => env('WORDPRESS_CONSUMER_SECRET'),
    'api_version' => env('WORDPRESS_API_VERSION', 'wc/v3'),
];

